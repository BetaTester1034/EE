MONGODB_URI = "mongodb://admin:fkyESQW59WBzTo44@cluster0-shard-00-00.arekh.mongodb.net:27017,cluster0-shard-00-01.arekh.mongodb.net:27017,cluster0-shard-00-02.arekh.mongodb.net:27017/?ssl=true&replicaSet=atlas-k1xfq0-shard-0&authSource=admin&retryWrites=true&w=majority&appName=Cluster0"

CAPTCHA_SITE_KEY = "6LcOkqUqAAAAAPSJIK69SKpBDuEYtK7r3vsFxbau"
CAPTCHA_SECRET_KEY = "6LcOkqUqAAAAAPNcn1kDPxzgFi32mzsS2Ji3onSd"

STRIPE_PUBLIC_KEY = "pk_test_51Qv15wFM2mYIuytCn0kS9cEKtT36l2CQRtBbzkbCxV3yR8P4Ilc881TUTzcUKJLgpQ582NpeznqCb0r0UvYSTDcG00cwMfXtOU"
STRIPE_SECRET_KEY = "sk_test_51Qv15wFM2mYIuytCEHnzGgJTTzNloD0LsvD78GLaf62oR3riNE2nCSf708QjuglzJ8ewlAjrUo05rskCo7zDydZ900FC3dCz8E"

GEMINI_API_KEY = "AIzaSyCg6Ubnswv0Or_4XQaEBBiCAeHQbvGlono"
IP_API_KEY = "053d2f0344a24cbfa8dc2c76b2f408bd"